#pragma once

#include "Customer.h"

class HappyHoursCustomer: public Customer {
public:
	HappyHoursCustomer() {
	}

	virtual ~HappyHoursCustomer() {
	}

	virtual void add(double price, int quantity) {
		drinks_.push_back(0.5 * price * quantity);
	}
};

