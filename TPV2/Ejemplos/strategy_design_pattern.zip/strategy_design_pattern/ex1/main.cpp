#include "Customer.h"
#include "HappyHoursCustomer.h"
#include "WeekEndCustomer.h"

void doStuff_1() {
    
    Customer a;
    Customer b;
    
    a.add(10.5,3);
    b.add(1.7,2);
    
    a.printBill();
    b.printBill();
}

void doStuff_2() {

	Customer a;
	HappyHoursCustomer b;
    WeekEndCustomer c;

    a.add(3,5);
    b.add(3,5);
    c.add(3,5);

    a.printBill();
    b.printBill();
    c.printBill();
}


int main() {
    doStuff_1();
    doStuff_2();
}
