#include "Customer.h"
#include "NormalStrategy.h"
#include "HappyHoursStrategy.h"
#include "WeekEndStrategy.h"


void doStuff() {
	NormalStrategy normalBilling;
	HappyHoursStrategy happyHoursBilling;
	WeekendStrategy weekendBilling;

	Customer a(&normalBilling);

	a.add(10.3, 3);
	a.add(10, 2);

	Customer b(&happyHoursBilling);

	b.add(10.3, 3);
	b.add(10, 2);

	a.setBillingStrategy(&happyHoursBilling);

	a.add(5.5, 2);

	a.setBillingStrategy(&weekendBilling);

	a.add(4, 10);

	a.printBill();
	b.printBill();

}

int main() {
	doStuff();
}
