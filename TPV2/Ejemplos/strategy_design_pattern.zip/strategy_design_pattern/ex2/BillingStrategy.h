#pragma once

class BillingStrategy {
public:
    virtual double getActualPrice(double price, int quantity) = 0;
    virtual ~BillingStrategy() {
    }
};
