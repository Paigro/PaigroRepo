#pragma once

#include <stdio.h>
#include "BillingStrategy.h"

class NormalStrategy : public BillingStrategy {
public:
    double getActualPrice(double price, int quantity) {
        return price*quantity;
    }
    ~NormalStrategy() {
    }
};

