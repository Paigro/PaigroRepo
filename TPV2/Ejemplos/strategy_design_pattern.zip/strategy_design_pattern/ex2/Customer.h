#pragma once

#include <stdio.h>
#include <vector>
#include <iostream>
#include "BillingStrategy.h"

using namespace std;

class Customer {
	BillingStrategy* bs_;
protected:
	vector<double> drinks_;
public:
	Customer(BillingStrategy* bs) :
			bs_(bs) {
	}

	virtual ~Customer() {
	}

	void setBillingStrategy(BillingStrategy* bs) {
		this->bs_ = bs;
	}

	virtual void add(double price, int quantity) {
		drinks_.push_back(bs_->getActualPrice(price, quantity));
	}

	void printBill() {
		double total = 0.0;
		for (double p : drinks_) {
			total += p;
		}
		cout << "Total: " << total << endl;
	}
};

