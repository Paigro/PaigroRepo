#pragma once

#include "BillingStrategy.h"

class HappyHoursStrategy: public BillingStrategy {
public:
	double getActualPrice(double price, int quantity) {
		return 0.5 * price * quantity;
	}
	~HappyHoursStrategy() {
	}
};

