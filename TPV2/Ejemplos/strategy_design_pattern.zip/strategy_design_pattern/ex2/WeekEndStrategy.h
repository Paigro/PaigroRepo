#pragma once

#include <stdio.h>
#include "BillingStrategy.h"

class WeekendStrategy : public BillingStrategy {
public:
    double getActualPrice(double price, int quantity) {
        return price*(quantity/3+ quantity%3==0?0:1);
    }
    ~WeekendStrategy() {        
    }
};

