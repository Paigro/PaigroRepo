// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>
#include <utility>
#include <vector>

#include "sdlutils/sdlutils_demo.h"
#include "utils/Vector2D.h"

struct Base1 {
	virtual ~Base1() {
	}
};

struct Base2 {
	virtual ~Base2() {
	}
};

struct Base3 {
	virtual ~Base3() {
	}
};

struct Derived: Base1, Base2, Base3 {
};

int main(int, char**) {

	Derived *x = new Derived();

	Base1 *b1 = x;
	Base2 *b2 = x;
	Base3 *b3 = x;

	std::cout << "x= " << x << std::endl;

	std::cout << std::endl << "---" << std::endl;
	std::cout << "b1= " << b1 << std::endl;
	std::cout << "b2= " << b2 << std::endl;
	std::cout << "b3= " << b3 << std::endl;

	std::cout << std::endl << "--- with dynamic_cast" << std::endl;
	std::cout << "b1= " << dynamic_cast<void*>(b1) << std::endl;
	std::cout << "b2= " << dynamic_cast<void*>(b2) << std::endl;
	std::cout << "b3= " << dynamic_cast<void*>(b3) << std::endl;

	return 0;
}

