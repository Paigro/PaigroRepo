#include <iostream>

#include "InFile.h"
#include "IOFile.h"
#include "OutFile.h"

using namespace std;

int main(int ac, char** av) {
	IOFile f;

	// f.open();  // The compiler complains when using this line
	f.InFile::open();
	f.OutFile::open();
	f.read();
	f.write();

    return 0;
}
