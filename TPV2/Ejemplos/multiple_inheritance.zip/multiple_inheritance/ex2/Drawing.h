#pragma once

/*
 *
 */
class Drawing {
public:
	Drawing();
	virtual ~Drawing();
	void virtual draw(/* some args */) = 0;
};

