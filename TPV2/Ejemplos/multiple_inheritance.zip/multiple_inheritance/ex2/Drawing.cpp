#include "Drawing.h"

Drawing::Drawing() {
}

Drawing::~Drawing() {
}

