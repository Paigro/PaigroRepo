#include "Animal.h"

Animal::Animal() {
}

Animal::~Animal() {
}

