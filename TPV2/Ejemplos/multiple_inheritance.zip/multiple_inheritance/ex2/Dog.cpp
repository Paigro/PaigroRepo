#include "Dog.h"

#include <iostream>

using namespace std;

Dog::Dog() {
}

Dog::~Dog() {
}

void Dog::eat() {
	cout << "Yum Yum ...." << endl;
}

void Dog::draw() {
    cout << "(.^.)" << endl;
}
