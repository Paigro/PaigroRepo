#include "OutFile.h"

#include <iostream>

using namespace std;

OutFile::OutFile(string name) : File(name) {
}

OutFile::~OutFile() {
}

void OutFile::write() {
	cout << "writing ..." << endl;
}
