#include "File.h"

#include <iostream>

File::File(string name) : name_(name) {
}

File::~File() {
}

void File::open() {
	cout << "Opening " << name_ << endl;
}

string File::getName() {
	return name_;
}
