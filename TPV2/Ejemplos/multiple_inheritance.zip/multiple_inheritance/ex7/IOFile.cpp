#include "IOFile.h"

IOFile::IOFile(string name) :
		File(name), InFile(name), OutFile(name) {
}

IOFile::~IOFile() {
}

