#pragma once

#include <string>

using namespace std;

/*
 *
 */
class File {
public:
	File(string name);
	virtual ~File();
	void open();
	string getName();
protected:
	string name_;
};
