#pragma once

#include "File.h"

/*
 *
 */
class OutFile : virtual public File {
public:
	OutFile(string name);
	virtual ~OutFile();
    void write();
};
