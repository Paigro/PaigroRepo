#pragma once

/*
 *
 */
class InFile {
public:
	InFile();
	virtual ~InFile();
    void read();
};
