#include <iostream>

#include "InFile.h"
#include "IOFile.h"
#include "OutFile.h"

using namespace std;


int main(int ac, char** av) {
	IOFile f;

	// f.open();  // The compiler complains when using this line
	f.InFile::open("a.txt");
	f.read();
	f.write();

	cout << "filename via InFile='"  << f.InFile::getName() << "'" << endl;
	cout << "filename via OutFile='" << f.OutFile::getName() << "'" << endl;
	cout << "filename via IOFile='"  << f.getName() << "'" << endl;
    return 0;
}
