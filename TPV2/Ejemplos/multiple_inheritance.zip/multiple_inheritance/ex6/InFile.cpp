#include "InFile.h"

#include <iostream>

using namespace std;

InFile::InFile() {
}

InFile::~InFile() {
}

void InFile::read() {
    cout << "reading ..." << endl;
}

