#pragma once

#include "File.h"

/*
 *
 */
class OutFile : virtual public File {
public:
	OutFile();
	virtual ~OutFile();
    void write();
};
