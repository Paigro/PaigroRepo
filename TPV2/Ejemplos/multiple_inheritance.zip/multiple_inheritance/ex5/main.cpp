#include <iostream>

#include "InFile.h"
#include "IOFile.h"
#include "OutFile.h"

using namespace std;

int main(int ac, char** av) {
	IOFile f;

	// f.open();  // The compiler complains when using this line
	f.InFile::open("a.txt");
	f.read();
	f.write();

	// the field 'name_' has two copies as well, one through InFile and one throw OutFile
	cout << "filename via InFile='" << f.InFile::getName() << "'" << endl;
	cout << "filename via OutFile='" << f.OutFile::getName() << "'" << endl;
    return 0;
}
