#pragma once

#include "File.h"

/*
 *
 */
class InFile : public File {
public:
	InFile();
	virtual ~InFile();
    void read();
};
