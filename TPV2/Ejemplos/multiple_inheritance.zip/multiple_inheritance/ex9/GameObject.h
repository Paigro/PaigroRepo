#pragma once

/*
 *
 */
class GameObject {
public:
	GameObject(double width, double height, double x, double y);
	virtual ~GameObject();
	virtual void render() = 0;
	virtual void update() = 0;
	double getX();
	double getY();
	double getW();
	double getH();
protected:
	double width_;
	double height_;
	double x_;
	double y_;
};
