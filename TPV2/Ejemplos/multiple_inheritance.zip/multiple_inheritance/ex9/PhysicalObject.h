#pragma once

/*
 *
 */
class PhysicalObject {
public:
	PhysicalObject();
	virtual ~PhysicalObject();
	virtual double getObjectWidth() = 0;
	virtual double getObjectHeight() = 0;
	virtual double getObjectXPos() = 0;
	virtual double getObjectYPos() = 0;
};
