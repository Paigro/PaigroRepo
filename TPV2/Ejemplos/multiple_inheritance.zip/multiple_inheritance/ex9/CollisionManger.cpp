#include "CollisionManger.h"

CollisionManger::CollisionManger() {
}

CollisionManger::~CollisionManger() {
}

bool CollisionManger::checkCollision(PhysicalObject* a,
		PhysicalObject* b) {
	return checkCollision_(a,b) || checkCollision_(b,a);
}

bool CollisionManger::checkCollision_(PhysicalObject* a, PhysicalObject* b) {
	return a->getObjectXPos() <= b->getObjectXPos()
			&& b->getObjectXPos() <= a->getObjectXPos() + a->getObjectWidth()
			&& a->getObjectYPos() <= b->getObjectYPos()
			&& b->getObjectYPos() <= a->getObjectYPos() + a->getObjectHeight();
}
