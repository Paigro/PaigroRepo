#pragma once

#include "MyGameObject.h"

/*
 *
 */
class Hero: public MyGameObject {
public:
	Hero(double width, double height, double x, double y);
	virtual ~Hero();
	virtual void render();
	virtual void update();
};
