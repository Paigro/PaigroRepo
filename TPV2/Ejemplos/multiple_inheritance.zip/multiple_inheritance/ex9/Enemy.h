#pragma once

#include "MyGameObject.h"

/*
 *
 */
class Enemy : public MyGameObject {
public:
	Enemy(double width, double height, double x, double y);
	Enemy();
	virtual ~Enemy();

	virtual void render();
	virtual void update();
};
