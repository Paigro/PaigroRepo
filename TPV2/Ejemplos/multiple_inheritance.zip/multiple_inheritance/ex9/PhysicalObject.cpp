#include "PhysicalObject.h"

PhysicalObject::PhysicalObject() {
}

PhysicalObject::~PhysicalObject() {
}

