#include "GameEngine.h"

GameEngine::GameEngine() : actors_() {
}

GameEngine::~GameEngine() {
}

void GameEngine::addGameObject(GameObject* o) {
	actors_.push_back(o);
}

void GameEngine::update() {
	for(GameObject* o : actors_ ) {
		o->update();
	}
}

void GameEngine::render() {
	for(GameObject* o : actors_ ) {
		o->render();
	}
}
