// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>
#include <vector>

using namespace std;



void f(int& x, int& y) {
	std::cout << "1" << std::endl;
}

void f(int& x, int&& y) {
	std::cout << "2" << std::endl;
}

void g(int &x, int&& y) {
	f(x,y);
}

int main() {
	int x=1;
	int y=2;
	// f(x,1);
	g(x,1);
}

