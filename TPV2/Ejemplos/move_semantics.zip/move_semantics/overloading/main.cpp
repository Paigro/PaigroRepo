// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>

using namespace std;

struct A {
	int i = 1;
	int foo() && {
		std::cout << "'this' is rvalue" << endl;
		return i;
	} // call to this overload is rvalue
	int& foo() & {
		std::cout << "'this' is lvalue" << endl;
		return i;
	} // call to this overload is lvalue
};

int main() {
	A x;
	auto &&a1 = x.foo();
	auto &&a2 = std::move(x).foo();
	auto &&a3 = A().foo();

	std::cout << is_same<decltype(a2), int&&>::value;

}
