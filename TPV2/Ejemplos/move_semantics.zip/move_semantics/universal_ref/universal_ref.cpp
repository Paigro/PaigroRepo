// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>

template<typename T>
void f(T &&x) {
	std::cout << __PRETTY_FUNCTION__ << std::endl;
	std::cout << std::is_rvalue_reference_v<decltype(x)> << std::endl;
}

class B {
};
template<typename T>
class A {
public:
	void f(T &&x) {
		std::cout << __PRETTY_FUNCTION__ << std::endl;
		std::cout << std::is_rvalue_reference_v<decltype(x)> << std::endl;
	}

	template<typename T1>
	void g(T1 &&x) {
		std::cout << __PRETTY_FUNCTION__ << std::endl;
		std::cout << std::is_rvalue_reference_v<decltype(x)> << std::endl;
	}
};

int main(int argc, char *argv[]) {
	int x = 1;
	f(1);
	f(x);
	f(std::move(x));

	A<int> a;
	a.f(1);
	a.f(std::move(x));
	a.g(1);
	a.g(std::move(x));
	a.g(x);
}


