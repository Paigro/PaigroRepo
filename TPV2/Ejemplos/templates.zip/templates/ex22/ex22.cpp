// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>

using namespace std;

class A {
public:
	A() {
		std::cout << "Default ctor. " << std::endl;
	}

	A(const A &o) {
		std::cout << "Copy ctor. " << std::endl;
	}

};

template<typename T>
void f(T a) {
}

template<typename T>
void g(T &a) {
}

int main(int ac, char **av) {
	A a;
	const A b;

	std::cout << "1" << std::endl;
	f(a);
	std::cout << "2" << std::endl;
	f(b);
	std::cout << "3" << std::endl;
	g(a);
	std::cout << "4" << std::endl;
	g(b);
	std::cout << "5" << std::endl;

	return 0;
}
