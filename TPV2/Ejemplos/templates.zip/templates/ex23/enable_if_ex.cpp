// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>
#include <type_traits>

using namespace std;


// Works only for integral types
template<typename T, class Enabled = void>
struct SomeType;

template<typename T>
struct SomeType<T, std::enable_if_t<std::is_integral_v<T>>> {
	T x;
};

int main(int ac, char **av) {
	SomeType<int> x;
//	SomeType<float> x; // ERROR
}
