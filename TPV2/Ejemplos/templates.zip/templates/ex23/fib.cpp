// This file is part of the course TPV2@UCM - Samir Genaim

#include <tuple>
#include <iostream>
#include <type_traits>

using std::__1::tuple_size;

using namespace std;

template<long N>
struct Fib {
	constexpr static long res = N * Fib<N - 1>::res;
};

template<>
struct Fib<0> {
	constexpr static long res = 1;
};

int main(int ac, char **av) {
	return Fib<5>::res;
}

