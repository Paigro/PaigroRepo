// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>

// A generic sort function
template<typename T>
void sort(T arr[], int size) {
	std::cout << "This is quick sort ..." << std::endl;
}

// Template Specialization: A function
// specialized for char data type
template<typename T>
void sort<char>(char arr[], int size) {

	std::cout << "This is count sort ..." << std::endl;
}

int main(int ac, char **av) {
	int a[] = { 12, 3, 23, 45, 3, 2 };
	char b[] = { 'a', 'f', 'e', '4', 'd', 's' };

	sort(a, 6);
	sort(b, 6);

}
