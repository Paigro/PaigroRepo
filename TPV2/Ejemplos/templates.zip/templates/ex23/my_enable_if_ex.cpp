// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>

using namespace std;

template<typename >
struct is_integral_aux {
	constexpr static bool value = false;
};

template<>
struct is_integral_aux<int> {
	constexpr static bool value = true;
};

template<>
struct is_integral_aux<long> {
	constexpr static bool value = true;
};

template<typename T>
constexpr bool is_integral_aux_v = is_integral_aux<T>::value;


template<bool B>
struct enable_if_aux {
};

template<>
struct enable_if_aux<true> {
	using type = void;
};

template<bool B>
using enable_if_aux_t = typename enable_if_aux<B>::type;


// Works only for integral types
template<typename T, typename Enabled = void>
struct SomeType;

template<typename T>
struct SomeType<T, enable_if_aux_t<is_integral_aux_v<T>>> {
	T x;
};

int main(int ac, char **av) {
	SomeType<int> x;
	// SomeType<float> y; // ERROR
}
