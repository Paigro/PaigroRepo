// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>
#include <type_traits>

using namespace std;

template<typename T>
struct SomeType {
	T x;
};

template<>
struct SomeType<int> {
	int x;
	int y;
};

template<>
struct SomeType<float> {
	int x;
	float z;
};

int main(int ac, char **av) {
	SomeType<char> a;
	SomeType<int> b;
	SomeType<float> c;
}
