// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>

// Substitution failure is not an error (SFINAE)

template<typename T, std::enable_if_t<std::is_integral_v<T>,
		bool> = true>
void foo(const T &f) {
	std::cout << ">>> messing with integral! " << f << std::endl;
}

template<typename T, std::enable_if_t<!std::is_integral_v<T>, bool> =
		true>
void foo(const T &f) {
	std::cout << ">>> messing with non integral! " << f << std::endl;
}

int main(int argc, char *argv[]) {
	foo(1);
	foo(1.2);
	foo("Hey!");
}

