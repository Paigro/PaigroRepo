// This file is part of the course TPV2@UCM - Samir Genaim


#pragma once

/*
 *
 */
template<typename T>
class Destructor {
public:
	Destructor() :
			managedObj_(nullptr) {
	}
	Destructor(T *o) :
			managedObj_(o) {
	}
	virtual ~Destructor() {
		if (managedObj_ != nullptr)
			delete managedObj_;
	}
	void setObject(T *o) {
		managedObj_ = o;
	}
private:
	T *managedObj_;
};

