// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

#include <memory>
#include <iostream>

using namespace std;
/*
 *
 */
class Singleton {
public:
	Singleton() {
	}
	virtual ~Singleton() {
		std::cout << "Destructor called ..." << std::endl;
	}
	static Singleton* instance() {
		if (instance_.get() == nullptr) {
			instance_.reset(new Singleton());
		}

		return instance_.get();
	}

	Singleton(Singleton&) = delete;
	Singleton& operator=(const Singleton&) = delete;
private:
	static unique_ptr<Singleton> instance_;
};

