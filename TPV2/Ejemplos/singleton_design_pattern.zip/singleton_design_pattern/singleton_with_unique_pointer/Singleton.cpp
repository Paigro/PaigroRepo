// This file is part of the course TPV2@UCM - Samir Genaim

#include "Singleton.h"

unique_ptr<Singleton> Singleton::instance_;
