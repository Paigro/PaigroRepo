// This file is part of the course TPV2@UCM - Samir Genaim

#include "Singleton.h"


int main() {
	Singleton::instance();

	cout << "End of main ..." << endl;
	return 0;
}
