// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

#include <iostream>

class FileSystem {
	static FileSystem* instance_;
public:
	FileSystem() {
		instance_ = nullptr;
	}

	FileSystem(FileSystem&) = delete;
	FileSystem& operator=(const FileSystem&) = delete;

	static FileSystem* instance() {
		if (instance_ == nullptr)
			instance_ = new FileSystem();
		return instance_;
	}

	void read() {
		std::cout << "reading ..." << std::endl;
	}

	void write() {
		std::cout << "writing ..." << std::endl;
	}
};
