// This file is part of the course TPV2@UCM - Samir Genaim

#include "FileSystem.h"

FileSystem* FileSystem::instance_ = nullptr;
