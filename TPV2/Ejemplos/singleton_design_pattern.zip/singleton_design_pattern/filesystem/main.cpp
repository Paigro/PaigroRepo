// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>
#include "FileSystem.h"

using namespace std;

void doStuff_1() {
    FileSystem* fs = FileSystem::instance();
    
    fs->read();
    fs->write();
 
    FileSystem* fs2 = FileSystem::instance();
    fs2->read();
    fs2->write();

    cout <<"Equal? " << (fs == fs2) << endl;
    
}

int main() {
    doStuff_1();
    
    return 0;
}

