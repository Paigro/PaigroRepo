// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

#include <iostream>

/*
 *
 */
class Singleton {
public:
	virtual ~Singleton() {
	}
	static Singleton* instance() {
		if (instance_ == nullptr) {
			instance_ = new Singleton();
		}

		return instance_;
	}
	void foo() {
		std::cout << "This is foo!" << std::endl;
	}

	Singleton(Singleton&) = delete;
	Singleton& operator=(const Singleton&) = delete;
private:
	Singleton() {
	}
	static Singleton *instance_;

};

