using UnityEngine.UIElements;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using Lab6_namespace;
using UnityEditor.PackageManager;

namespace Lab5b_namespace
{
    public class Lab5c : MonoBehaviour
    {
        List<Individuo> individuos;

        Individuo selecIndividuo;

        VisualElement tarjeta1;
        VisualElement tarjeta2;
        VisualElement tarjeta3;
        VisualElement tarjeta4;

        TextField input_nombre;
        TextField input_apellido;

        VisualElement panda;
        VisualElement perro;
        VisualElement gato;
        private string backgroundSprite = "panda";
        private string newName = " ";
        private string newSurname = " ";



        private void OnEnable()
        {
            VisualElement root = GetComponent<UIDocument>().rootVisualElement;

            tarjeta1 = root.Q("Tarjeta1");
            tarjeta2 = root.Q("Tarjeta2");
            tarjeta3 = root.Q("Tarjeta3");
            tarjeta4 = root.Q("Tarjeta4");

            input_nombre = root.Q<TextField>("InputNombre");
            input_apellido = root.Q<TextField>("InputApellido");

            individuos = Basedatos.getData();

            panda = root.Q<VisualElement>("panda");
            perro = root.Q<VisualElement>("perro");
            gato = root.Q<VisualElement>("gato");

            VisualElement panelDcha = root.Q("dcha");

            panelDcha.RegisterCallback<ClickEvent>(seleccionTarjeta);


            List<VisualElement> lista_tarjetas = panelDcha.Children().ToList();
            lista_tarjetas.ForEach(eleme =>
            {
                eleme.RegisterCallback<ClickEvent>(SeleccionarTarjeta);
            });

            input_nombre.RegisterCallback<ChangeEvent<string>>(CambioNombre);
            input_apellido.RegisterCallback<ChangeEvent<string>>(CambioApellido);
            panda.RegisterCallback<ClickEvent>(CambioPanda);
            perro.RegisterCallback<ClickEvent>(CambioPerro);
            gato.RegisterCallback<ClickEvent>(CambioGato);
            InitializeUI();
        }
        void SeleccionarTarjeta(ClickEvent evt)
        {
            VisualElement tarjeta = evt.target as VisualElement;
            VisualElement top = tarjeta.Q<VisualElement>("top");
            VisualElement mid = tarjeta.Q<VisualElement>("mid");
            VisualElement bottom = tarjeta.Q<VisualElement>("bottom");



            Label name = tarjeta.Q<Label>("name"); 
            Label surname = tarjeta.Q<Label>("surname");


            top.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(backgroundSprite));
            //name.text += "hola";
            //surname.text += newSurname.ToString();
        }
        void CambioNombre(ChangeEvent<string> evt)
        {
            newName = evt.newValue;
            Debug.Log(newName);
        }
        void CambioApellido(ChangeEvent<string> evt)
        {
            newSurname = evt.newValue;
        }
        void CambioImagen(/*ChangeEvent<string> evt*/)
        {
            //Falta implementar
        }
        void seleccionTarjeta(ClickEvent e)
        {
            VisualElement tarjeta = e.target as VisualElement;
            selecIndividuo = tarjeta.userData as Individuo;

            input_nombre.SetValueWithoutNotify(selecIndividuo.Nombre);
            input_apellido.SetValueWithoutNotify(selecIndividuo.Apellido);
        }
        void InitializeUI()
        {

        }
        void CambioPanda(ClickEvent evt)
        {
            backgroundSprite = "panda";
            Debug.Log("Sprite panda");
        }
        void CambioPerro(ClickEvent evt)
        {
            backgroundSprite = "perro";
            Debug.Log("Sprite perro");

        }
        void CambioGato(ClickEvent evt)
        {
            backgroundSprite = "gato";
            Debug.Log("Sprite gato");
        }
    }
}

