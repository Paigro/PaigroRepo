using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace Lab6_namespace
{
    public static class JSonHelperIndividuo
    {
        public static List<Individuo> FromJson<Individuo>(string json)
        {
            ListaIndividuo<Individuo> listaIndividuos = JsonUtility.FromJson<ListaIndividuo<Individuo>>(json);
            return listaIndividuos.Individuos;
        }
        public static string ToJson<Individuo>(List<Individuo> lista)
        {
            ListaIndividuo<Individuo> listaIndividuos = new ListaIndividuo<Individuo>();
            listaIndividuos.Individuos = lista;
            return JsonUtility.ToJson(listaIndividuos);
        }
        public static string ToJson<Individuo>(List<Individuo> lista, bool prettyPrint)
        {
            ListaIndividuo<Individuo> listaIndividuos = new ListaIndividuo<Individuo>();
            listaIndividuos.Individuos = lista;
            return JsonUtility.ToJson(listaIndividuos, prettyPrint);
        }

        [Serializable]
        private class ListaIndividuo<Individuo>
        {
            public List<Individuo> Individuos;
        }
    }
}