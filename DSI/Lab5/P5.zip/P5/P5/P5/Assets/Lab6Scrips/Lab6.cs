using System.Collections;

using Unity.VisualScripting;

using UnityEngine;
using UnityEngine.UIElements;

using System;
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using Lab5b_namespace;
using System.Xml.Linq;

namespace Lab6_namespace
{
    public class Lab6 : MonoBehaviour
    {
        VisualElement botonCrear;
        Toggle toggleModificar;
        VisualElement contenedor_dcha;
        TextField input_nombre;
        TextField input_apellido;
        Individuo individuoSelec;

        VisualElement gato;
        VisualElement girafa;
        VisualElement conejo;
        private string backgroundSprite = "panda";

        private int maxIndvs = 4;
        private int indvs = 0;


        List<Individuo> list_individuos = new List<Individuo>();
        private void OnEnable()
        {
            VisualElement root = GetComponent<UIDocument>().rootVisualElement;

            contenedor_dcha = root.Q<VisualElement>("Dcha");
            input_nombre = root.Q<TextField>("InputN");
            input_apellido = root.Q<TextField>("InputA");
            botonCrear = root.Q<VisualElement>("BotonCrear");
            toggleModificar = root.Q<Toggle>("ToggleModificar");

            gato = root.Q<VisualElement>("gato");
            girafa = root.Q<VisualElement>("girafa");
            conejo = root.Q<VisualElement>("conejo");

            contenedor_dcha.RegisterCallback<ClickEvent>(SeleccionarTarjeta);
            botonCrear.RegisterCallback<ClickEvent>(NuevaTarjeta);
            input_nombre.RegisterCallback<ChangeEvent<string>>(CambioNombre);
            input_apellido.RegisterCallback<ChangeEvent<string>>(CambioApellido);
            gato.RegisterCallback<ClickEvent>(SeleccionGato);
            girafa.RegisterCallback<ClickEvent>(SeleccionGirafa);
            conejo.RegisterCallback<ClickEvent>(SeleccionConejo);
        }
        void NuevaTarjeta(ClickEvent evt)
        {
            if (!toggleModificar.value && indvs < maxIndvs)
            {
                VisualTreeAsset plantilla = Resources.Load<VisualTreeAsset>("plantilla");
                VisualElement tarjetaPlatilla = plantilla.Instantiate();

                contenedor_dcha.Add(tarjetaPlatilla);
                tarjetas_borde_negro();
                tarjetas_borde_blanco(tarjetaPlatilla);

                Individuo indv = new Individuo(input_nombre.value, input_apellido.value);
                Tarjeta tarj = new Tarjeta(tarjetaPlatilla, indv);
                individuoSelec = indv;

                list_individuos.Add(indv);
                /* list_individuos.ForEach(elem =>
                 {
                     Debug.Log(elem.Nombre + " " + elem.Apellido);
                     string jsonIndividuo = JsonUtility.ToJson(elem);
                     Debug.Log(jsonIndividuo);
                 });*/
                string listToJson = JSonHelperIndividuo.ToJson(list_individuos, true); // PAIGRO AQUI
                Debug.Log(listToJson);

                /* List<Individuo> jsonToLista = JSonHelperIndividuo.FromJson<Individuo>(listToJson);
                 jsonToLista.ForEach(elem =>
                 {
                     Debug.Log(elem.Nombre + " " + elem.Apellido);
                 });*/
                indvs++;
            }
        }

        void CambioNombre(ChangeEvent<string> evt)
        {
            if (toggleModificar.value)
            {
                individuoSelec.Nombre = evt.newValue;
            }
        }
        void CambioApellido(ChangeEvent<string> evt)
        {
            if (toggleModificar.value)
            {
                individuoSelec.Apellido = evt.newValue;
            }
        }
        void SeleccionarTarjeta(ClickEvent evt)
        {
            VisualElement miTarjeta = evt.target as VisualElement;
            individuoSelec = miTarjeta.userData as Individuo;

            input_nombre.SetValueWithoutNotify(individuoSelec.Nombre);
            input_apellido.SetValueWithoutNotify(individuoSelec.Apellido);
            toggleModificar.value = true;

            tarjetas_borde_negro();
            tarjetas_borde_blanco(miTarjeta);
        }
        void tarjetas_borde_negro()
        {
            List<VisualElement> lista_tarjetas = contenedor_dcha.Children().ToList();
            lista_tarjetas.ForEach(elem =>
            {
                VisualElement tarjeta = elem.Q("plantilla");

                tarjeta.style.borderBottomColor = Color.black;
                tarjeta.style.borderRightColor = Color.black;
                tarjeta.style.borderTopColor = Color.black;
                tarjeta.style.borderLeftColor = Color.black;

            });
        }
        void tarjetas_borde_blanco(VisualElement tar)
        {
            VisualElement tarjeta = tar.Q("plantilla");

            tarjeta.style.borderBottomColor = Color.white;
            tarjeta.style.borderRightColor = Color.white;
            tarjeta.style.borderTopColor = Color.white;
            tarjeta.style.borderLeftColor = Color.white;

            VisualElement top = tar.Q("top");
            top.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(backgroundSprite));
        }
        void SeleccionGato(ClickEvent evt)
        {
            backgroundSprite = "gato";
            Debug.Log("Sprite gato");
        }
        void SeleccionGirafa(ClickEvent evt)
        {
            backgroundSprite = "girafa";
            Debug.Log("Sprite girafa");
        }
        void SeleccionConejo(ClickEvent evt)
        {
            backgroundSprite = "conejo";
            Debug.Log("Sprite conejo");
        }
    }
}