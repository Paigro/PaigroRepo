IMPORTANTE

En esta carpeta encontrarás scripts para practicar en R. Por favor, sigue el siguiente orden:

1- Importar_Datos_Excel_a_R

2- Cómo_Gráficar_Histogramas_en_R

3- Cómo_graficar_Barras_en_R

4- Rendimientos_E_Descriptiva_en_R

5- Análisis_descriptivo_fuente_datos_Salarios_R

6- Ejemplo_Uso_DataFrame_análisis_Descriptivo_en_R

7- Ejemplo_de_Regresión_Lineal_Simple_en_R (PDF)

8- Modelo_de_regresión_lineal_simple_R

Para una mejor comprensión, apóyate en la documentación, presentaciones y apuntes de R disponibles en el Campus Virtual.

Observa en cada ejemplo o ejercicio las salidas de R (consola) y las gráficas correspondientes (utilidades). Presta atención a la interpretación de las salidas.