#include "IG2App.h"

using namespace Ogre;
using namespace std;

const int IG2App::EarthDistance = 200;
 
bool IG2App::keyPressed(const OgreBites::KeyboardEvent& evt){
        
    // ESC key finished the rendering...
    if (evt.keysym.sym == SDLK_ESCAPE){
        getRoot()->queueEndRendering();
    }
    
        
    else if (evt.keysym.sym == SDLK_w){
                
        // Re-positioning
//        alpha -= 5;
//        earth->setPosition(EarthDistance*Ogre::Math::Cos(Ogre::Degree(alpha)), 0, EarthDistance*Ogre::Math::Sin(Ogre::Degree(alpha)));
//        cout << "Re-positioning with alpha= " << alpha << endl;
        
        // Fake node
//        earthFake->yaw(Ogre::Degree(alpha));
//        cout << "Fake node with alpha= " << alpha << endl;
        
        // The trick!
        earth->translate(-EarthDistance, 0, 0, SceneNode::TS_LOCAL);
        earth->yaw(Ogre::Degree(alpha));
        earth->translate(EarthDistance, 0, 0, SceneNode::TS_LOCAL);
        
        //cout << "The trick with alpha= " << Alpha << endl;
    }
    
  return true;
}

void IG2App::shutdown(){
    
  mShaderGenerator->removeSceneManager(mSM);
  mSM->removeRenderQueueListener(mOverlaySystem);  
					
  mRoot->destroySceneManager(mSM);  

  delete mTrayMgr;  mTrayMgr = nullptr;
  delete mCamMgr; mCamMgr = nullptr;
  
  // do not forget to call the base 
  IG2ApplicationContext::shutdown(); 
}

void IG2App::setup(void){
    
    // do not forget to call the base first
    IG2ApplicationContext::setup();

    // Create the scene manager
    mSM = mRoot->createSceneManager();

    // Register our scene with the RTSS
    mShaderGenerator->addSceneManager(mSM);

    mSM->addRenderQueueListener(mOverlaySystem);
    mTrayMgr = new OgreBites::TrayManager("TrayGUISystem", mWindow.render);
    mTrayMgr->showFrameStats(OgreBites::TL_BOTTOMLEFT);
    addInputListener(mTrayMgr);
    
    // Adds the listener for this object
    addInputListener(this);
    setupScene();
}

void IG2App::setupScene(void){
    
    //------------------------------------------------------------------------
    // Creating the camera
    
    Camera* cam = mSM->createCamera("Cam");
    cam->setNearClipDistance(1);
    cam->setFarClipDistance(10000);
    cam->setAutoAspectRatio(true);
            
    mCamNode = mSM->getRootSceneNode()->createChildSceneNode("nCam");
    mCamNode->attachObject(cam);
    mCamNode->setPosition(0, 0, 1000);
    mCamNode->lookAt(Ogre::Vector3(0, 0, 0), Ogre::Node::TS_WORLD);
        
    // And tell it to render into the main window
    Viewport* vp = getRenderWindow()->addViewport(cam);
    vp->setBackgroundColour(Ogre::ColourValue(0.25, 0.25, 0.25));
    
    // Camera manager
    mCamMgr = new OgreBites::CameraMan(mCamNode);
    addInputListener(mCamMgr);
    mCamMgr->setStyle(OgreBites::CS_ORBIT);
    
    
    //------------------------------------------------------------------------
    // Creating the light
    
    Light* luz = mSM->createLight("Luz");
    luz->setType(Ogre::Light::LT_DIRECTIONAL);
    luz->setDiffuseColour(0.75, 0.75, 0.75);

    mLightNode = mSM->getRootSceneNode()->createChildSceneNode("nLuz");
    mLightNode->attachObject(luz);
    mLightNode->setDirection(Ogre::Vector3(0, 0, -1));

    
        
    //------------------------------------------------------------------------
    // Sun and earth
    
    sun =  mSM->getRootSceneNode()->createChildSceneNode();
    Entity* ent = mSM->createEntity("sphere.mesh");
    sun->attachObject(ent);
    sun->scale (0.2, 0.2, 0.2);
        
    
    // Re-positioning
//    alpha = 0;
//    earth =  mSM->getRootSceneNode()->createChildSceneNode();
//    ent = mSM->createEntity("sphere.mesh");
//    earth->attachObject(ent);
//    earth->scale (0.1, 0.1, 0.1);
//    earth->setPosition(EarthDistance*Ogre::Math::Cos(Ogre::Degree(alpha)), 0, EarthDistance*Ogre::Math::Sin(Ogre::Degree(alpha)));
        
    
    // Fake node
//    alpha = -5;
//    earthFake = mSM->getRootSceneNode()->createChildSceneNode("tierra fake");
//    earth = earthFake->createChildSceneNode("tierra");
//    ent = mSM->createEntity("sphere.mesh");
//    earth->translate(EarthDistance, 0, 0);
//    earth->scale(0.1, 0.1, 0.1);
//    earth->attachObject(ent);
    
    
    // The trick
    alpha = -5;
    earth =  mSM->getRootSceneNode()->createChildSceneNode();
    ent = mSM->createEntity("sphere.mesh");
    earth->attachObject(ent);
    earth->translate(EarthDistance, 0, 0);
    earth->scale(0.1, 0.1, 0.1);
}


