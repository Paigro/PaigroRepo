#include "IG2App.h"

using namespace Ogre;
using namespace std;


const int IG2App::CLOCK_RADIUS = 300;

bool IG2App::keyPressed(const OgreBites::KeyboardEvent& evt){
        
    // ESC key finished the rendering...
    if (evt.keysym.sym == SDLK_ESCAPE){
        getRoot()->queueEndRendering();
    }
    
    
    // Rotate spheres (a)
    else if (evt.keysym.sym == SDLK_a){
        hoursNode->roll(Ogre::Degree(5));
        cout << "Rotating spheres 5 radians" << endl;
    }
    
    // Rotate spheres (s)
    else if (evt.keysym.sym == SDLK_s){
        hoursNode->roll(Ogre::Degree(-5));
        cout << "Rotating spheres -5 radians" << endl;
    }
    
    // Rotate the hours hand (d)
    else if (evt.keysym.sym == SDLK_d){
        hourHandNode->roll(Ogre::Degree(5));
        cout << "Rotating hours hand 5 radians" << endl;
    }
    
    // Rotate the hours hand (f)
    else if (evt.keysym.sym == SDLK_f){
        hourHandNode->roll(Ogre::Degree(-5));
        cout << "Rotating hours hand -5 radians" << endl;
    }
//    
//    // Rotate the hourHandNodePositional hand (g)
//    else if (evt.keysym.sym == SDLK_g){
//        hourHandNodePositional->roll(Ogre::Degree(5));
//        cout << "Rotating hourHandNodePositional hand 5 radians" << endl;
//    }
//    
//    // Rotate the hourHandNodePositional hand (h)
//    else if (evt.keysym.sym == SDLK_h){
//        hourHandNodePositional->roll(Ogre::Degree(-5));
//        cout << "Rotating hourHandNodePositional hand -5 radians" << endl;
//    }
//        
  return true;
}

void IG2App::shutdown(){
    
  mShaderGenerator->removeSceneManager(mSM);
  mSM->removeRenderQueueListener(mOverlaySystem);  
					
  mRoot->destroySceneManager(mSM);  

  delete mTrayMgr;  mTrayMgr = nullptr;
  delete mCamMgr; mCamMgr = nullptr;
  
  // do not forget to call the base 
  IG2ApplicationContext::shutdown(); 
}

void IG2App::setup(void){
    
    // do not forget to call the base first
    IG2ApplicationContext::setup();

    // Create the scene manager
    mSM = mRoot->createSceneManager();

    // Register our scene with the RTSS
    mShaderGenerator->addSceneManager(mSM);

    mSM->addRenderQueueListener(mOverlaySystem);
    mTrayMgr = new OgreBites::TrayManager("TrayGUISystem", mWindow.render);
    mTrayMgr->showFrameStats(OgreBites::TL_BOTTOMLEFT);
    addInputListener(mTrayMgr);
    
    // Adds the listener for this object
    addInputListener(this);
    setupScene();
}

void IG2App::setupScene(void){
    
    //------------------------------------------------------------------------
    // Creating the camera
    
    Camera* cam = mSM->createCamera("Cam");
    cam->setNearClipDistance(1);
    cam->setFarClipDistance(10000);
    cam->setAutoAspectRatio(true);
            
    mCamNode = mSM->getRootSceneNode()->createChildSceneNode("nCam");
    mCamNode->attachObject(cam);
    mCamNode->setPosition(0, 0, 1000);
    mCamNode->lookAt(Ogre::Vector3(0, 0, 0), Ogre::Node::TS_WORLD);
        
    // And tell it to render into the main window
    Viewport* vp = getRenderWindow()->addViewport(cam);
    vp->setBackgroundColour(Ogre::ColourValue(0.25, 0.25, 0.25));
    
    // Camera manager
    mCamMgr = new OgreBites::CameraMan(mCamNode);
    addInputListener(mCamMgr);
    mCamMgr->setStyle(OgreBites::CS_ORBIT);
    
    
    //------------------------------------------------------------------------
    // Creating the light
    
    Light* luz = mSM->createLight("Luz");
    luz->setType(Ogre::Light::LT_DIRECTIONAL);
    luz->setDiffuseColour(0.75, 0.75, 0.75);

    mLightNode = mSM->getRootSceneNode()->createChildSceneNode("nLuz");
    mLightNode->attachObject(luz);
    mLightNode->setDirection(Ogre::Vector3(0, 0, -1));
    
    //------------------------------------------------------------------------
    // The clock
    
    // Create the main node and hours node (from root)
    clockNode = mSM->getRootSceneNode()->createChildSceneNode("clock");
    hoursNode = clockNode->createChildSceneNode("hours");
    
    // Offset for sphere positioning
    double inc = 2 * 3.1415 / 12;
    Ogre::SceneNode* mHourNode;
    
    // Create the spheres
    for (int i = 0; i < 12; i++) {
        Entity* hour = mSM->createEntity("sphere.mesh");
        mHourNode = hoursNode->createChildSceneNode("Hour " + std::to_string(i + 1));
        mHourNode->setScale(0.4, 0.4, 0.4);
        mHourNode->attachObject(hour);
        mHourNode->setPosition(CLOCK_RADIUS * Ogre::Math::Cos(inc * i), CLOCK_RADIUS * Ogre::Math::Sin(inc * i), 0);
    }
    
        
    
    // Modify the even hours
    Ogre::SceneNode* nodo;
    
    // Get each node by its name
    for (int i = 0; i < 12; i++) {
        if (i % 2 == 1){
            nodo = mSM->getSceneNode("Hour " + std::to_string(i+1));
            nodo->setScale(0.2, 0.2, 0.2);
        }
    }
    
    

    // Adding the clock hands
    handsNode = clockNode->createChildSceneNode("hands");
        
    // Hours hand
    hourHandNode = handsNode->createChildSceneNode("Hours Hand");
    Entity* cubo = mSM->createEntity("cube.mesh");
    hourHandNode->attachObject(cubo);
    hourHandNode->setScale(2, 0.15, 0.02);
    hourHandNode->setPosition(80, 0, 0);
    
    // Minutes hand
    minuteHandNode = handsNode->createChildSceneNode("Minutes Hand");
    cubo = mSM->createEntity("cube.mesh");
    minuteHandNode->attachObject(cubo);
    minuteHandNode->setScale(2.5, 0.1, 0.02);
    minuteHandNode->setPosition(0, 100, 0);
    minuteHandNode->roll(Ogre::Degree(90));
    
    // Seconds hand
    secondHandNode = handsNode->createChildSceneNode("Seconds Hand");
    cubo = mSM->createEntity("cube.mesh");
    secondHandNode->attachObject(cubo);
    secondHandNode->setScale(2.5, 0.02, 0.02);
    secondHandNode->setPosition(100, 0, 0);
    secondHandNode->setPosition(0, -100, 0);
    secondHandNode->roll(Ogre::Degree(-90));
                                                                
                             
    
    
    
    //    // Make hours hands independet
    //    hourHandNodePositional = clockNode->createChildSceneNode("hoursPositional");
    //    hourHandNode = hourHandNodePositional->createChildSceneNode("Hours Hand");
    
    
}


