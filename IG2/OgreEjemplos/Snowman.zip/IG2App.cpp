#include "IG2App.h"

using namespace Ogre;
using namespace std;

bool IG2App::keyPressed(const OgreBites::KeyboardEvent& evt){
        
    // ESC key finished the rendering...
    if (evt.keysym.sym == SDLK_ESCAPE){
        getRoot()->queueEndRendering();
    }
        
    
    // Event to set inherit scale true (a)
    else if (evt.keysym.sym == SDLK_a){
        head->setInheritScale(true);
        cout << "Head is set to setInheritScale(true)" << endl;
    }
    
    // Events to set inherit scale false (s)
    else if (evt.keysym.sym == SDLK_s){
        head->setInheritScale(false);
        cout << "Head is set to setInheritScale(false)" << endl;
    }
    
    // Event to set inherit orientation true (d)
    else if (evt.keysym.sym == SDLK_d){
        head->setInheritOrientation(true);
        cout << "Head is set to setInheritOrientation(true)" << endl;
    }
    
    // Events to set inherit orientation false (f)
    else if (evt.keysym.sym == SDLK_f){
        head->setInheritOrientation(false);
        cout << "Head is set to setInheritOrientation(false)" << endl;
    }
        
    // Events to yaw the head (z)
    else if (evt.keysym.sym == SDLK_z){
        snowman->yaw(Radian(Math::PI/10.0));
        cout << "Snowman is rotating in the Y axis " << Math::PI/10.0 << " radians" << endl;
    }
    
    // Events to yaw the head (x)
    else if (evt.keysym.sym == SDLK_x){
        snowman->yaw(Radian(-Math::PI/10.0));
        cout << "Snowman is rotating in the Y axis " << -Math::PI/10.0 << " radians" << endl;
    }
        
    // Events to scale up the head (c)
    else if (evt.keysym.sym == SDLK_c){
        snowman->scale (2, 2, 2);
        cout << "Snowman is scaling up" << endl;
    }
    
    // Events to scale down the head (v)
    else if (evt.keysym.sym == SDLK_v){
        snowman->scale(0.5, 0.5, 0.5);
        cout << "Snowman is scaling down" << endl;
    }
    
  return true;
}

void IG2App::shutdown(){
    
  mShaderGenerator->removeSceneManager(mSM);
  mSM->removeRenderQueueListener(mOverlaySystem);  
					
  mRoot->destroySceneManager(mSM);  

  delete mTrayMgr;  mTrayMgr = nullptr;
  delete mCamMgr; mCamMgr = nullptr;
  
  // do not forget to call the base 
  IG2ApplicationContext::shutdown(); 
}

void IG2App::setup(void){
    
    // do not forget to call the base first
    IG2ApplicationContext::setup();

    // Create the scene manager
    mSM = mRoot->createSceneManager();

    // Register our scene with the RTSS
    mShaderGenerator->addSceneManager(mSM);

    mSM->addRenderQueueListener(mOverlaySystem);
    mTrayMgr = new OgreBites::TrayManager("TrayGUISystem", mWindow.render);
    mTrayMgr->showFrameStats(OgreBites::TL_BOTTOMLEFT);
    addInputListener(mTrayMgr);
    
    // Adds the listener for this object
    addInputListener(this);
    setupScene();
}

void IG2App::setupScene(void){
    
    //------------------------------------------------------------------------
    // Creating the camera
    
    Camera* cam = mSM->createCamera("Cam");
    cam->setNearClipDistance(1);
    cam->setFarClipDistance(10000);
    cam->setAutoAspectRatio(true);    
            
    mCamNode = mSM->getRootSceneNode()->createChildSceneNode("nCam");
    mCamNode->attachObject(cam);
    mCamNode->setPosition(0, 0, 1000);
    mCamNode->lookAt(Ogre::Vector3(0, 0, 0), Ogre::Node::TS_WORLD);
        
    // And tell it to render into the main window
    Viewport* vp = getRenderWindow()->addViewport(cam);
    vp->setBackgroundColour(Ogre::ColourValue(0.25, 0.25, 0.25));
    
    // Camera manager
    mCamMgr = new OgreBites::CameraMan(mCamNode);
    addInputListener(mCamMgr);
    mCamMgr->setStyle(OgreBites::CS_ORBIT);
    
    
    //------------------------------------------------------------------------
    // Creating the light
    
    Light* luz = mSM->createLight("Luz");
    luz->setType(Ogre::Light::LT_DIRECTIONAL);
    luz->setDiffuseColour(0.75, 0.75, 0.75);
    

    mLightNode = mSM->getRootSceneNode()->createChildSceneNode("nLuz");
    mLightNode->attachObject(luz);
    mLightNode->setDirection(Ogre::Vector3(0, 0, -1));
    
    
    //------------------------------------------------------------------------
    // The snowman
    
    // Create the main scene node (from root)
    snowman = mSM->getRootSceneNode()->createChildSceneNode("snowMan");
    
    // Create the head
    head = snowman->createChildSceneNode("head");
    Ogre::Entity* ent = mSM->createEntity("sphere.mesh");
    head->attachObject(ent);
           
    // Nodes for the head (eyes, nose and mouth)
    leftEye = head->createChildSceneNode("leftEye");
    ent = mSM->createEntity("sphere.mesh");
    leftEye->attachObject(ent);
    leftEye->setScale(0.1, 0.1, 0.1);
    leftEye->setPosition(30, 30, 100);

    rightEye = head->createChildSceneNode("rightEye");
    ent = mSM->createEntity("sphere.mesh");
    rightEye->attachObject(ent);
    rightEye->setScale(0.1, 0.1, 0.1);
    rightEye->setPosition(-30, 30, 100);
    
    nose = head->createChildSceneNode("nose");
    ent = mSM->createEntity("sphere.mesh");
    nose->attachObject(ent);
    nose->setScale(0.1, 0.1, 0.1);
    nose->setPosition(0, 15, 100);

    mouth = head->createChildSceneNode("mouth");
    ent = mSM->createEntity("sphere.mesh");
    mouth->attachObject(ent);
    mouth->setScale(0.2, 0.1, 0.1);
    mouth->setPosition(0, -20, 100);
    
    // Create the body
    body = snowman->createChildSceneNode("body");
    ent = mSM->createEntity("sphere.mesh");
    body->attachObject(ent);
    body->setScale(1.5, 1.5, 1.5);
    
    bellyButton = body->createChildSceneNode("bellyButton");
    ent = mSM->createEntity("sphere.mesh");
    bellyButton->attachObject(ent);
    bellyButton->setScale(0.1, 0.1, 0.1);
    bellyButton->setPosition(0, 0, 100);
    
    // Move the body (and also the belly button)
    body->setPosition(0, -230, 0);
}


