#include "IG2App.h"

using namespace Ogre;
using namespace std;

bool IG2App::keyPressed(const OgreBites::KeyboardEvent& evt){
        
    // ESC key finished the rendering...
    if (evt.keysym.sym == SDLK_ESCAPE){
        getRoot()->queueEndRendering();
    }
    
    
    else if (evt.keysym.sym == SDLK_w){
        pointZero->translate(0, 0, -10);
        cout << "Point zero is at position: " << pointZero->getPosition() << endl;
    }
    
    else if (evt.keysym.sym == SDLK_a){
        pointZero->translate(-10, 0, 0);
        cout << "Point zero is at position: " << pointZero->getPosition() << endl;
    }
    
    else if (evt.keysym.sym == SDLK_s){
        pointZero->translate(0, 0, 10);
        cout << "Point zero is at position: " << pointZero->getPosition() << endl;
    }
    
    else if (evt.keysym.sym == SDLK_d){
        pointZero->translate(10, 0, 0);
        cout << "Point zero is at position: " << pointZero->getPosition() << endl;
    }    
    
    
    
    else if (evt.keysym.sym == SDLK_k){
        node3->yaw(Degree(10));
    }
    
    
        
        
//    cout << "Position of the body: " << body->getPosition() << endl;
//    cout << "Position of the belly button: " << bellyButton->getPosition() << endl;
    
    
    // Event to move sinbad (parent)
//    if (evt.keysym.sym == SDLK_k){
//        
//        mNodeParent->yaw(Radian(Math::PI/10.0));
//        
//        cout << "Position of parent node: " << mNodeParent->getPosition() << endl;
//        cout << "Position of child node: " << mNodeChild->getPosition() << endl;
//    }
    
  return true;
}

void IG2App::shutdown(){
    
  mShaderGenerator->removeSceneManager(mSM);
  mSM->removeRenderQueueListener(mOverlaySystem);  
					
  mRoot->destroySceneManager(mSM);  

  delete mTrayMgr;  mTrayMgr = nullptr;
  delete mCamMgr; mCamMgr = nullptr;
  
  // do not forget to call the base 
  IG2ApplicationContext::shutdown(); 
}

void IG2App::setup(void){
    
    // do not forget to call the base first
    IG2ApplicationContext::setup();

    // Create the scene manager
    mSM = mRoot->createSceneManager();

    // Register our scene with the RTSS
    mShaderGenerator->addSceneManager(mSM);

    mSM->addRenderQueueListener(mOverlaySystem);
    mTrayMgr = new OgreBites::TrayManager("TrayGUISystem", mWindow.render);
    mTrayMgr->showFrameStats(OgreBites::TL_BOTTOMLEFT);
    addInputListener(mTrayMgr);
    
    // Adds the listener for this object
    addInputListener(this);
    setupScene();
}

void IG2App::setupScene(void){
    
    //------------------------------------------------------------------------
    // Creating the camera
    
    Camera* cam = mSM->createCamera("Cam");
    cam->setNearClipDistance(1);
    cam->setFarClipDistance(10000);
    cam->setAutoAspectRatio(true);
            
    mCamNode = mSM->getRootSceneNode()->createChildSceneNode("nCam");
    mCamNode->attachObject(cam);
    mCamNode->setPosition(0, 0, 1000);
    mCamNode->lookAt(Ogre::Vector3(0, 0, 0), Ogre::Node::TS_WORLD);
        
    // And tell it to render into the main window
    Viewport* vp = getRenderWindow()->addViewport(cam);
    vp->setBackgroundColour(Ogre::ColourValue(0.25, 0.25, 0.25));
    
    // Camera manager
    mCamMgr = new OgreBites::CameraMan(mCamNode);
    addInputListener(mCamMgr);
    mCamMgr->setStyle(OgreBites::CS_ORBIT);
    
    
    //------------------------------------------------------------------------
    // Creating the light
    
    Light* luz = mSM->createLight("Luz");
    luz->setType(Ogre::Light::LT_DIRECTIONAL);
    luz->setDiffuseColour(0.75, 0.75, 0.75);

    mLightNode = mSM->getRootSceneNode()->createChildSceneNode("nLuz");
    mLightNode->attachObject(luz);
    mLightNode->setDirection(Ogre::Vector3(0, 0, -1));

    
        
    //------------------------------------------------------------------------
    // Testing transformations
    
//    // Creating the pointZero sphere to help place the elements in the scene
      Entity* ent = mSM->createEntity("sphere.mesh");
//    pointZero =  mSM->getRootSceneNode()->createChildSceneNode();
//    pointZero->attachObject(ent);
//    pointZero->scale (0.2, 0.2, 0.2);
    
    
    
    // Example 1
    //----------
    
      // Lets create a Sinbad parent called node
//    node = mSM->getRootSceneNode()->createChildSceneNode();
//    Entity* ent = mSM->createEntity("Sinbad.mesh");
//    node->attachObject(ent);
//    node->setPosition(0, 0, 100);
//    cout << "Simbad parent (node) position is: " << node->getPosition() << endl;
//
//    // Lets scale the Sinbad parent (node) with respect to the local space
//    node->scale(50, 50, 50);
//
//    // Rotations are, by default, applied with respect to the local space
//    node->yaw(Degree(180.0));
//    
//    // Lets create a Sinbad son called node2 (from its parent, node)
//    node2 = node->createChildSceneNode();
//    ent = mSM->createEntity("Sinbad.mesh");
//    node2->attachObject(ent);
//    node2->setPosition(10, 0, 0);
//    cout << "Simbad son (node2) position after setPosition(10, 0, 0) is: " << node2->getPosition() << endl;
//
//    // Translation applied to node2 are, by default, with respect to its parent (node)
//    node2->translate(0, 0, 10);
//    cout << "Simbad son (node2) position after translate(0, 0, 10) is: " << node2->getPosition() << endl;
//
//    // Lets create a Sinbad son called node3 (from its parent, node)
//    node3 = node->createChildSceneNode();
//    ent = mSM->createEntity("Sinbad.mesh");
//    node3->attachObject(ent);
//    node3->setPosition(20, 0, 0);
//    cout << "Simbad son (node3) position after setPosition(20, 0, 0) is: " << node3->getPosition() << endl;
//    node3->translate(0, 0, 10);
//    cout << "Simbad son (node3) position after translate(0, 0, 10) is: " << node3->getPosition() << endl;

    // ---> Who in the scene is the parent? Who is node3? And... why?
       
     
    
    // Example 2
    //----------
    
//    pointZero =  mSM->getRootSceneNode()->createChildSceneNode();
//    Entity* ent = mSM->createEntity("sphere.mesh");
//    pointZero->attachObject(ent);
//    pointZero->scale (0.2, 0.2, 0.2);
//    
//    // Lets create a Sinbad parent called node
//    node = mSM->getRootSceneNode()->createChildSceneNode();
//    ent = mSM->createEntity("Sinbad.mesh");
//    node->attachObject(ent);
//    node->setPosition(0, 0, 100);
//    node->scale(50, 50, 50);
//    node->yaw(Degree(180.0));
//    cout << "Simbad parent (node) position is: " << node->getPosition() << endl;
//
//    // Lets create a Sinbad son called node2 (from its parent, node)
//    node2 = node->createChildSceneNode();
//    ent = mSM->createEntity("Sinbad.mesh");
//    node2->attachObject(ent);
//    node2->setPosition(10, 0, 0);
//    node2->translate(0, 0, 10);
//    cout << "Simbad son (node2) position after translate(0, 0, 10) is: " << node2->getPosition() << endl;
//
//    // Lets create a Sinbad son called node3 (from its parent, node)
//    node3 = node->createChildSceneNode();
//    ent = mSM->createEntity("Sinbad.mesh");
//    node3->attachObject(ent);
//    node3->setPosition(20, 0, 0);
//    node3->translate(0, 0, 500, Ogre::Node::TS_WORLD);
//    cout << "Simbad son (node3) position after translate(0, 0, 500) is: " << node3->getPosition() << endl;

    
    // ---> Why is node3 in this position? Use the pointZero sphere... ;)
    
    
    
    // Example 3
    //----------
    
//    // Lets create a Sinbad parent called node
//    node = mSM->getRootSceneNode()->createChildSceneNode();
//    ent = mSM->createEntity("Sinbad.mesh");
//    node->attachObject(ent);
//    node->setPosition(0, 0, 400);
//    node->scale(50, 50, 50);
//    node->yaw(Degree(180.0));
//    cout << "Simbad parent (node) position is: " << node->getPosition() << endl;
//
//    // Lets create a Sinbad son called node2 (from its parent, node)
//    node2 = node->createChildSceneNode();
//    ent = mSM->createEntity("Sinbad.mesh");
//    node2->attachObject(ent);
//    node2->yaw(Ogre::Degree(45));
//    node2->translate(0, 0, 20);
//    cout << "Simbad son (node2) position after translate(0, 0, 20) is: " << node2->getPosition() << endl;
//
//    // Lets create a Sinbad son called node3 (from its parent, node)
//    node3 = node->createChildSceneNode();
//    ent = mSM->createEntity("Sinbad.mesh");
//    node3->attachObject(ent);
//    node3->yaw(Ogre::Degree(45));
//    node3->translate(0, 0, 20, Ogre::Node::TS_LOCAL);
//    cout << "Simbad son (node3) position after translate(0, 0, 20) is: " << node3->getPosition() << endl;
    
    

    // Example 4
    //----------
    
//    // Lets create a Sinbad parent called node
//    node = mSM->getRootSceneNode()->createChildSceneNode();
//    ent = mSM->createEntity("Sinbad.mesh");
//    node->attachObject(ent);
//    cout << "Simbad parent (node) position is: " << node->getPosition() << endl;
//
//    // Lets create a Sinbad son called node2 (from its parent, node)
//    SceneNode* node2 = mSM->getRootSceneNode()->createChildSceneNode();
//    ent = mSM->createEntity("Sinbad.mesh");
//    node2->attachObject(ent);
//    node2->setPosition(10, 0, 0);
//    node2->yaw(Ogre::Degree(90));
//    node2->roll(Ogre::Degree(90));
//    cout << "Simbad son (node2) position after transformations is: " << node2->getPosition() << endl;
//
//    // Lets create a Sinbad son called node3 (from its parent, node)
//    node3 = node->createChildSceneNode();
//    ent = mSM->createEntity("Sinbad.mesh");
//    node3->attachObject(ent);
//    node3->setPosition(20, 0, 0);
//    node3->yaw(Ogre::Degree(90), Ogre::Node::TS_WORLD);
//    node3->roll(Ogre::Degree(90),Ogre::Node::TS_WORLD);
//    cout << "Simbad son (node3) position after translate(0, 0, 20) is: " << node3->getPosition() << endl;
    
    
    // Example 5
    //----------
    
    // Lets create a Sinbad parent called node
    node = mSM->getRootSceneNode()->createChildSceneNode();
    ent = mSM->createEntity("Sinbad.mesh");
    node->attachObject(ent);
    cout << "Simbad parent (node) position is: " << node->getPosition() << endl;

    // Lets create a Sinbad son called node2 (from its parent, node)
    SceneNode* node2 = mSM->getRootSceneNode()->createChildSceneNode(); 
    ent = mSM->createEntity("Sinbad.mesh");
    node2->attachObject(ent);
    node2->setPosition(10, 0, 0);
    node2->yaw(Ogre::Degree(90)); 
    node2->roll(Ogre::Degree(90));
    cout << "Simbad son (node2) position after transformations is: " << node2->getPosition() << endl;

    // Lets create a Sinbad son called node3 (from its parent, node)
    SceneNode* node3 = node->createChildSceneNode();
    ent = mSM->createEntity("Sinbad.mesh");
    node3->setPosition(20, 0, 0);
    node3->attachObject(ent);
    node3->yaw(Ogre::Degree(90), Ogre::Node::TS_PARENT);
    node3->roll(Ogre::Degree(90), Ogre::Node::TS_PARENT);
    cout << "Simbad son (node3) position after translate(0, 0, 20) is: " << node3->getPosition() << endl;
}


