using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParallaxScroller : MonoBehaviour
{
    #region Parameters
    /// <summary>
    /// Speed use to move the texture
    /// </summary>
    [SerializeField]
    private float _scrollSpeed;
    #endregion

    #region Referencez
    /// <summary>
    /// Reference to own Sprite Renderer
    /// </summary>
    private SpriteRenderer _mySpriteRenderer;
    /// <summary>
    /// Reference to own Material
    /// </summary>
    private Material _myMaterial;
    #endregion

    #region methods
    /// <summary>
    /// Disables the component, so the texture stops
    /// </summary>
    private void Stop()
    {
        _scrollSpeed = 0;
    }
    #endregion

    // Start is called before the first frame update
    void Start()
    {
        _mySpriteRenderer = GetComponent<SpriteRenderer>();
        _myMaterial = _mySpriteRenderer.material;
    }

    // Update is called once per frame
    void Update()
    {
        _myMaterial.mainTextureOffset += new Vector2(_scrollSpeed,0) * Time.deltaTime;
    }
}
